import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ArnauPaint extends PApplet {

PImage logo;
PImage icono;
PImage goma;
PImage papelera;
PImage paleta;
PImage textSize;
PImage text;
PImage cursor;
PFont font1;
PImage export;
PImage importImg;
PImage up;
PImage down;

String[] exportName = new String[2];
boolean exporting = false, writingExportName = false, keyTypedVar=false, ccgui = false;
String selected="black", exportNameVar, v="1.0.0";
int xp=20, yp=20, wp=50, hp=30, r=0, g=0, b=0, size = 20, lines = 415;
int xcr=90, ycr=20, wcr=50, hcr=30;
int xcg=160, ycg=20, wcg=50, hcg=30;
int xcb=230, ycb=20, wcb=50, hcb=30;
int xcn=300, ycn=20, wcn=50, hcn=30;
int xcc=370, ycc=20, wcc=50, hcc=30;
int xb=440, yb=20, wb=50, hb=30;
int xm=0, ym=0, wm=1200, hm=(2*(2*yb)+hb);
int xi=230, yi=70, wi=50, hi=30;
int xt=510, yt=20, wt=50, ht=30;
int xts=510, yts=20, wts=50, hts=30;
int xe=20, ye=70, we=50, he=30;
int xen=90, yen=70, wen=120, hen=30;
int xclose=width-30, yclose=0, wclose=30, hclose=30;
int xs=510, ys=20, ws=150, hs=30;
int xccgui=750, yccgui=20, wccgui=120, hccgui=80;

public void setup(){
  background(255);
  stroke(204, 102, 0);
  logo = loadImage("dibuix_arnau_transparent_marca_aigua.png");
  icono = loadImage("logo.png");
  papelera = loadImage("papelera.png");
  goma = loadImage("goma.png");
  paleta = loadImage("paleta.png");
  textSize = loadImage("tamaño_fuente.png");
  text = loadImage("text.png");
  cursor = loadImage("hand-0.png");
  font1 = createFont("Roboto-Thin.ttf", 32);
  export = loadImage("export.png");
  importImg = loadImage("import.png");
  noStroke();
  surface.setTitle("ArnauPaint v" + v + " - By Arnau MinePlay");
  surface.setIcon(icono);
  imageMode(CENTER);
  image(icono, width/2, height/2, width/30, width/30);
  
  xclose=width-30;
  wm=width;
  up = loadImage("flecha_arriba.png");
  down = loadImage("flecha_abajo.png");
}

public void draw(){
  exportNameVar = exportName[0];
  if((keyPressed && (key == 'r' && !writingExportName)) || (mouseX>xcr && mouseX<xcr+wcr && mouseY>ycr && mouseY<ycr+hcr && mousePressed)){
    fill(255, 0, 0);
    r = 255;
    g = 0;
    b = 0;
    selected = "red";
  }
  if((keyPressed && (key == 'g' && !writingExportName)) || (mouseX>xcg && mouseX<xcg+wcg && mouseY>ycg && mouseY<ycg+hcg && mousePressed)){
    fill(0, 255, 0);
    r = 0;
    g = 255;
    b = 0;
    selected = "green";
  }
  if((keyPressed && (key == 'b' && !writingExportName)) || (mouseX>xcb && mouseX<xcb+wcb && mouseY>ycb && mouseY<ycb+hcb && mousePressed)){
    fill(0, 0, 255);
    r = 0;
    g = 0;
    b = 255;
    selected = "blue";
  }
  if((keyPressed && (key == 'n' && !writingExportName)) || (mouseX>xcn && mouseX<xcn+wcn && mouseY>ycn && mouseY<ycn+hcn && mousePressed)){
    fill(0, 0, 0);
    r = 0;
    g = 0;
    b = 0;
    selected = "black";
  }
  if((keyPressed && (key == 'e' && !writingExportName)) || (mouseX>xb && mouseX<xb+wb && mouseY>yb && mouseY<yb+hb && mousePressed)){
    fill(255, 255, 255);
    r = 255;
    g = 255;
    b = 255;
    selected = "erase";
  }
  
  if(mousePressed && !(selected == "text")){
    noStroke();
    ellipse(mouseX,mouseY,size,size);
  }
  
  if(mouseX>xp && mouseX<xp+wp && mouseY>yp && mouseY<yp+hp && mousePressed){
    background(255);
  }
  
  if(mouseX>xe && mouseX<xe+we && mouseY>ye && mouseY<ye+he && mousePressed){
    exporting = true;
  }
  
  if(mouseX>xen && mouseX<xen+wen && mouseY>yen && mouseY<yen+hen && mousePressed){
    writingExportName = true;
  }
  else{
    if(mousePressed){
      writingExportName = false;
    }
  }
  
  if(mouseX>xclose && mouseX<xclose+wclose && mouseY>yclose && mouseY<yclose+hclose && mousePressed){
    exit();
  }
  
  if(mouseX>xts+wts-25/2 && mouseX<xts+wts+25-25/2 && mouseY>yts+(hts/2)-25/2 && mouseY<yts+(hts/2)+25-25/2 && mousePressed && size<50){
    size = size+1;
  }
  
  if(mouseX>xts+wts+25-25/2 && mouseX<xts+wts+50-25/2 && mouseY>yts+(hts/2)-25/2 && mouseY<yts+(hts/2)+25-25/2 && mousePressed && size>3){
    size = size-1;
  }
  
  if(mouseX>xcc && mouseX<xcc+wcc && mouseY>ycc && mouseY<ycc+hcc && mousePressed){
    selected = "custom";
    fill(r, g, b);
    ccgui = true;
  }
  else{
    if(mousePressed && !(mouseX>xccgui && mouseX<xccgui+wccgui && mouseY>yccgui && mouseY<yccgui+hccgui && mousePressed)){
      ccgui = false;
    }
  }
  
  if(mouseX>xccgui+75-25/2 && mouseX<xccgui+75+25/2 && mouseY>yccgui+14-25/2 && mouseY<yccgui+14+25/2 && mousePressed && r<255 && selected == "custom"){
    r = r+1;
  }
  
  if(mouseX>xccgui+100-25/2 && mouseX<xccgui+100+25/2 && mouseY>yccgui+14-25/2 && mouseY<yccgui+14+25/2 && mousePressed && r>0 && selected == "custom"){
    r = r-1;
  }
  
  if(mouseX>xccgui+75-25/2 && mouseX<xccgui+75+25/2 && mouseY>yccgui+14+25-25/2 && mouseY<yccgui+14+25+25/2 && mousePressed && g<255 && selected == "custom"){
    g = g+1;
  }
  
  if(mouseX>xccgui+100-25/2 && mouseX<xccgui+100+25/2 && mouseY>yccgui+14+25-25/2 && mouseY<yccgui+14+25+25/2 && mousePressed && g>0 && selected == "custom"){
    g = g-1;
  }
  
  if(mouseX>xccgui+75-25/2 && mouseX<xccgui+75+25/2 && mouseY>yccgui+14+50-25/2 && mouseY<yccgui+14+50+25/2 && mousePressed && b<255 && selected == "custom"){
    b = b+1;
  }
  
  if(mouseX>xccgui+100-25/2 && mouseX<xccgui+100+25/2 && mouseY>yccgui+14+50-25/2 && mouseY<yccgui+14+50+25/2 && mousePressed && b>0 && selected == "custom"){
    b = b-1;
  }
  
  //if(mouseX>xt && mouseX<xt+wt && mouseY>yt && mouseY<yt+ht && mousePressed){
    //selected = "text";
  //}
  
  fill(200);
  rect(xm,ym,wm,hm);
  fill(r, g, b);
  
  fill(100);
  rect(xp,yp,wp,hp);
  fill(r, g, b);
  
  if(selected == "red"){stroke(204, 102, 0);}
  fill(255, 0, 0);
  rect(xcr,ycr,wcr,hcr);
  fill(r, g, b);
  noStroke();
  
  if(selected == "green"){stroke(204, 102, 0);}
  fill(0, 255, 0);
  rect(xcg,ycg,wcg,hcg);
  fill(r, g, b);
  noStroke();
  
  if(selected == "blue"){stroke(204, 102, 0);}
  fill(0, 0, 255);
  rect(xcb,ycb,wcb,hcb);
  fill(r, g, b);
  noStroke();
  
  if(selected == "custom"){stroke(204, 102, 0);}
  fill(r, g, b);
  rect(xcc,ycc,wcc,hcc);
  fill(r, g, b);
  noStroke();
  
  if(selected == "erase"){stroke(204, 102, 0);}
  fill(100);
  rect(xb,yb,wb,hb);
  fill(r, g, b);
  noStroke();
  
  if(selected == "black"){stroke(204, 102, 0);}
  fill(0);
  rect(xcn,ycn,wcn,hcn);
  fill(r, g, b);
  noStroke();
  
  //if(selected == "text"){stroke(204, 102, 0);}
  //fill(100);
  //rect(xt,yt,wt,ht);
  //fill(r, g, b);
  //noStroke();
  
  fill(100);
  rect(xts,yts,wts,hts);
  fill(r, g, b);
  noStroke();
  
  fill(255);
  rect(xe,ye,we,he);
  fill(r, g, b);
  
  //fill(255);
  //rect(xi,yi,wi,hi);
  //fill(r, g, b);
  
  fill(100);
  rect(xs,ys,ws,hs);
  fill(r, g, b);
  
  if(mouseX>xclose && mouseX<xclose+wclose && mouseY>yclose && mouseY<yclose+hclose){
    fill(155, 0, 0);
  }
  else{
    fill(255, 0, 0);
  }
  rect(xclose,yclose,wclose,hclose);
  fill(r, g, b);
  if(ccgui){
    fill(r+100, g+100, b+100);
    rect(xccgui,yccgui,wccgui,hccgui);
    fill(r, g, b);
  }
  
  if(selected == "exportingName"){stroke(204, 102, 0);}
  if(writingExportName){
    fill(230);
    rect(xen,yen,wen,hen);
    fill(0);
    textSize(15);
    if(exportNameVar == null){
      exportNameVar = "";
      exportName[0] = exportNameVar;
    }
    else{
      textAlign(LEFT, CENTER);
      textSize(24);
      text(exportNameVar,xen+5, yen+((hen/5)+5));
    }
  }
  else{
    fill(255);
    rect(xen,yen,wen,hen);
    if(trim(exportName[0]) == null){
      fill(100);
      textSize(24);
      textAlign(LEFT, CENTER);
      text("Nombre", xen+5, yen+((hen/5)+5));
    }
    else{
      fill(0);
      textSize(24);
      textAlign(LEFT, CENTER);
      text(trim(exportName[0]), xen+5, yen+((hen/5)+5));
    }
  }
  fill(r, g, b);
  
  if(exporting){
  fill(0);
  rect(xm,ym,wm,hm);
  fill(r, g, b);
  }
  
  imageMode(CENTER);
  image(logo, 80, height-80);
  
  if(!exporting){
  imageMode(CENTER);
  image(papelera, xp+(wp/2), yp+(hp/2), 25, 25);
  
  //imageMode(CENTER);
  //image(text, xt+(wt/2), yt+(ht/2), 20, 20);
  
  imageMode(CENTER);
  image(textSize, xts+(wts/2), yts+(hts/2), 25, 25);
  
  imageMode(CENTER);
  image(paleta, xcc+(wcc/2), ycc+(hcc/2), 25, 25);
  
  imageMode(CENTER);
  image(up, xts+wts, yts+(hts/2), 25, 25);
  
  imageMode(CENTER);
  image(down, xts+wts+25, yts+(hts/2), 25, 25);
  
  if(ccgui){
    imageMode(CENTER);
    image(up, xccgui+75, yccgui+14, 25, 25);
  
    imageMode(CENTER);
    image(down, xccgui+100, yccgui+14, 25, 25);
  
    imageMode(CENTER);
    image(up, xccgui+75, yccgui+14+25, 25, 25);
  
    imageMode(CENTER);
    image(down, xccgui+100, yccgui+14+25, 25, 25);
  
    imageMode(CENTER);
    image(up, xccgui+75, yccgui+14+50, 25, 25);
  
    imageMode(CENTER);
    image(down, xccgui+100, yccgui+14+50, 25, 25);
  }
    
  imageMode(CENTER);
  image(goma, xb+(wb/2), yb+(hb/2), 20, 20);
  
  imageMode(CENTER);
  image(export, xe+(we/2), ye+(he/2), 20, 20);
  
  //imageMode(CENTER);
  //image(importImg, xi+(wi/2), ye+(he/2), 50, 50);
  }
  
  if(ccgui){
    textAlign(LEFT, TOP);
    textSize(25);
    
    fill(155, 0, 0);
    text(r, xccgui+10, yccgui);
  
    fill(0, 155, 0);
    text(g, xccgui+10, yccgui+25);
  
    fill(0, 0, 155);
    text(b, xccgui+10, yccgui+50);
    textAlign(LEFT, CENTER);
  }
  
  if(!exporting){
    fill(50);
    textAlign(LEFT, CENTER);
    text(size, xts+wts+45, yts+hts-18);
    textFont(font1);
  }
  
  if(!exporting){
    
    textAlign(LEFT, CENTER);
    text("Un proyecto con " + lines + " lineas de codigo", 180, height-30);
  }
  else{
    fill(255);
    textSize(100);
    textAlign(LEFT, CENTER);
    text("Hecho con ArnauPaint",xp,50);
    textSize(32);
    imageMode(CENTER);
    image(paleta, 1100, 50,100, 100);
  }
  fill(r, g, b);
  if(!exporting){
    cursor(cursor, 0, 0);
  }
  else{
    noCursor();
  }
  
  
  if(writingExportName && keyTypedVar && ((keyPressed && key == BACKSPACE)|| exportNameVar.length() < 7)){
    exportName[1] = str(key);
    exportNameVar = join(exportName, "");
    exportName[0] = exportNameVar;
    keyTypedVar=false;
    if(keyPressed && key == BACKSPACE && exportNameVar.length()>1){
      exportNameVar = exportNameVar.substring(0, exportNameVar.length()-2);
      exportName[0] = exportNameVar;
    }
  }
  
  if(exporting){
    if(exportNameVar != null){
      saveFrame("saves\\" + trim(exportNameVar) + ".png");
    }
    else{
      saveFrame("saves\\SinNombre.png");
    }
    exporting = false;
  }
  exportNameVar = exportName[0];
}

public void keyTyped(){
  keyTypedVar=true;
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#6C6C6C", "--hide-stop", "ArnauPaint" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
